/*
 * ClusteringProblemFactory.cpp
 *
 *  Created on: May 30, 2013
 *      Author: mario
 */

#include "include/ClusteringProblemFactory.h"

namespace problem {

ClusteringProblemFactory::ClusteringProblemFactory() {
	// TODO Auto-generated constructor stub

}

ClusteringProblemFactory::~ClusteringProblemFactory() {
	// TODO Auto-generated destructor stub
}

} /* namespace problem */
