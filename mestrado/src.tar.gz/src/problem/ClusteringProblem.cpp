/*
 * ClusteringProblem.cpp
 * Base clustering problem class.
 *
 *  Created on: May 6, 2013
 *      Author: mario
 */

#include "include/ClusteringProblem.h"

namespace problem {

ClusteringProblem::ClusteringProblem() {
	// TODO Auto-generated constructor stub

}

ClusteringProblem::~ClusteringProblem() {
	// TODO Auto-generated destructor stub
}


} /* namespace problem */
