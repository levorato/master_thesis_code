/*
 * ResolutionStrategy.cpp
 *
 *  Created on: 30/04/2013
 *      Author: czt0
 */

#include "include/ResolutionStrategy.h"

namespace resolution {

ResolutionStrategy::ResolutionStrategy() {
	// TODO Auto-generated constructor stub

}

ResolutionStrategy::~ResolutionStrategy() {
	// TODO Auto-generated destructor stub
}

} /* namespace resolution */
