/*
 * ProblemSolverFacade.h
 *
 *  Created on: May 1, 2013
 *      Author: mario
 */

#ifndef PROBLEMSOLVERFACADE_H_
#define PROBLEMSOLVERFACADE_H_

namespace resolution {

class ProblemSolverFacade {
public:
	ProblemSolverFacade();
	virtual ~ProblemSolverFacade();
};

#endif /* PROBLEMSOLVERFACADE_H_ */

} // namespace resolution
