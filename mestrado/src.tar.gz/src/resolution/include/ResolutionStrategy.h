/*
 * ResolutionStrategy.h
 *
 *  Created on: 30/04/2013
 *      Author: czt0
 */

#ifndef RESOLUTIONSTRATEGY_H_
#define RESOLUTIONSTRATEGY_H_

namespace resolution {

class ResolutionStrategy {
public:
	ResolutionStrategy();
	virtual ~ResolutionStrategy();
};

} /* namespace resolution */
#endif /* RESOLUTIONSTRATEGY_H_ */
