/*
 * ProblemSolverFacade.cpp
 *
 *  Created on: May 1, 2013
 *      Author: mario
 */

#include "include/ProblemSolverFacade.h"

namespace resolution {

ProblemSolverFacade::ProblemSolverFacade() {
	// TODO Auto-generated constructor stub

}

ProblemSolverFacade::~ProblemSolverFacade() {
	// TODO Auto-generated destructor stub
}

} // namespace resolution
