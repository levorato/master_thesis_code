/*
 * Pool.cpp
 *
 *  Created on: 30/04/2013
 *      Author: czt0
 */

#include "include/Pool.h"

namespace resolution {
namespace grasp {

Pool::Pool() {
	// TODO Auto-generated constructor stub

}

Pool::~Pool() {
	// TODO Auto-generated destructor stub
}

} /* namespace grasp */
} /* namespace resolution */
