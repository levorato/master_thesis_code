/*
 * PositiveNegativeModularityGainFunctionII.cpp
 *
 *  Created on: Jul 18, 2013
 *      Author: mario
 */

#include "include/PositiveNegativeModularityGainFunctionII.h"

namespace resolution {
namespace grasp {

PositiveNegativeModularityGainFunctionII::PositiveNegativeModularityGainFunctionII(SignedGraph* g) :
				ModularityGainFunction::ModularityGainFunction(g) {
	// TODO Auto-generated constructor stub

}

PositiveNegativeModularityGainFunctionII::~PositiveNegativeModularityGainFunctionII() {
	// TODO Auto-generated destructor stub
}

// TODO calculate the modularity matrix of weighed graphs
void PositiveNegativeModularityGainFunctionII::calculateModularityMatrix() {
	int m = graph->getM();
	int numberOfNodes = graph->getN();
	double pos_degree[numberOfNodes], neg_degree[numberOfNodes];
	// Prestore the degrees for optimezed lookup
	for(int i = 0; i < numberOfNodes; i++) {
		neg_degree[i] = graph->getNegativeDegree(i);
		pos_degree[i] = graph->getPositiveDegree(i);
	}

	for(int i = 0; i < numberOfNodes; i++) {
		for(int j = 0; j < numberOfNodes; j++) {
			double a = 0.0;
			if(graph->getEdge(i, j) > 0) {
				a = 1.0;
			} else if(graph->getEdge(i, j) < 0) {
				a = -1.0;
			}
			modularityMatrix[i][j] = a +
					( ( (neg_degree[i] * neg_degree[j]) - (pos_degree[i] * pos_degree[j]) ) / (2.0 * m) );
		}
	}
	modularityMatrixCalculated = true;
}

int PositiveNegativeModularityGainFunctionII::getType() {
	return GainFunction::POSITIVE_NEGATIVE_MODULARITY_II;
}

} /* namespace grasp */
} /* namespace resolution */
