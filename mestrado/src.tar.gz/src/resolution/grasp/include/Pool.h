/*
 * Pool.h
 *
 *  Created on: 30/04/2013
 *      Author: czt0
 */

#ifndef POOL_H_
#define POOL_H_

namespace resolution {
namespace grasp {

class Pool {
public:
	Pool();
	virtual ~Pool();
};

} /* namespace grasp */
} /* namespace resolution */

#endif /* POOL_H_ */
