/*
 * GraspPR.cpp
 *
 *  Created on: 30/04/2013
 *      Author: czt0
 */

#include "include/GraspPR.h"

namespace resolution {
namespace grasp {

GraspPR::GraspPR() {
	// TODO Auto-generated constructor stub

}

GraspPR::~GraspPR() {
	// TODO Auto-generated destructor stub
}

} /* namespace resolution */
} /* namespace grasp */
