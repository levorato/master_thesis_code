/*
 * GainFunction.cpp
 *
 *  Created on: Jun 18, 2013
 *      Author: mario
 */

#include "include/GainFunction.h"

namespace resolution {
namespace grasp {

GainFunction::GainFunction(SignedGraph* g) : graph(g) {
	// TODO Auto-generated constructor stub

}

GainFunction::~GainFunction() {
	// TODO Auto-generated destructor stub
}

} /* namespace grasp */
} /* namespace resolution */
